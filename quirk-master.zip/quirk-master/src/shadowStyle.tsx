// Copy/pasted from the from the Uchiha clan's jutsu
import theme from "./theme";

export default {
  shadowColor: theme.darkText,
  shadowOffset: { width: 0, height: 1 },
  shadowRadius: 3,
  shadowOpacity: 0.05,
  elevation: 1,
};
