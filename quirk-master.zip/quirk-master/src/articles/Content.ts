export default interface Content {
  pages: string[];
  title: string;
  description: string;
  slug: string;
}
